const nameGirl = 'Em';
const giftUrl = 'http://nodemy.vn';
const eventName = 'Chúc Mừng 20-10';
const titleCard = 'Tặng người ấy';
const contentCard = 'Chúc honey của anh 20/10 tràn ngập niềm vui và những nụ cười. Mong điều đẹp nhất sẽ đến với em trong hôm nay và cả những ngày sau';

// phần dưới dành cho các bạn biết code, nếu muốn chỉnh ảnh đơn giản với base64
// Cần hỗ trợ hãy liên hệ: 
// Mr-Nam http://facebook.com/nam.nodemy
// Các bạn muốn học lập trình thì tham gia Nhóm zalo tự học lập trình nhé: https://zalo.me/g/yhdkef092
const giftImage = 'hot-girl.png';
const base64 = '';
const giftImageBase64 = "data:image/png;base64, " + base64;
